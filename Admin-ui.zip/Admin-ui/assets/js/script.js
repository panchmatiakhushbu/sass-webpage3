/*sidebar js start */
var main = document.querySelector(".main");
var sidebar = document.querySelector(".sidebar");
var menutoggle = document.querySelector("#menu-toggle");

menutoggle.addEventListener("click", function(e) {
    menutoggle.classList.toggle("active");
    main.classList.toggle("active");
    sidebar.classList.toggle("active");

    if (sidebar.classList.contains("active")) {
        menutoggle.querySelector("i").classList.remove("fa-bars");
    } else {
        menutoggle.querySelector("i").classList.add("fa-bars");
    }
});

/*sidebar js end */

/* dropdown js start */

$(".custom-select").each(function() {
    var classes = $(this).attr("class"),
        id = $(this).attr("id"),
        name = $(this).attr("name");
    var template = '<div class="' + classes + '">';
    template += '<span class="custom-select-trigger">' + $(this).attr("placeholder") + '</span>';
    template += '<div class="custom-options">';
    $(this).find("option").each(function() {
        template += '<span class="custom-option ' + $(this).attr("class") + '" data-value="' + $(this).attr("value") + '">' + $(this).html() + '</span>';
    });
    template += '</div></div>';

    $(this).wrap('<div class="custom-select-wrapper"></div>');
    $(this).hide();
    $(this).after(template);
});
$(".custom-option:first-of-type").hover(function() {
    $(this).parents(".custom-options").addClass("option-hover");
}, function() {
    $(this).parents(".custom-options").removeClass("option-hover");
});
$(".custom-select-trigger").on("click", function() {
    $('html').one('click', function() {
        $(".custom-select").removeClass("opened");
    });
    $(this).parents(".custom-select").toggleClass("opened");
    event.stopPropagation();
});
$(".custom-option").on("click", function() {
    $(this).parents(".custom-select-wrapper").find("select").val($(this).data("value"));
    $(this).parents(".custom-options").find(".custom-option").removeClass("selection");
    $(this).addClass("selection");
    $(this).parents(".custom-select").removeClass("opened");
    $(this).parents(".custom-select").find(".custom-select-trigger").text($(this).text());
});

/* dropdown js end */

/* line-chart js start */

/* first chart js start */
var ctx = document.getElementById("myChart1").getContext('2d');

var myChart1 = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Tokyo", "Mumbai", "Mexico City", "Shanghai", "Sao Paulo", "New York", "Karachi", "Buenos Aires", "Delhi", "Moscow"],
        datasets: [{
                label: 'Series 1',
                data: [500, 50, 2424, 14040, 14141, 4111, 4544, 47, 5555, 6811], // Specify the data values array
                fill: false,
                borderColor: '#D8D8D8',
                backgroundColor: '#D8D8D8',
                borderWidth: 1
            },
            {
                label: 'Series 2',
                data: [1288, 88942, 44545, 7588, 99, 242, 1417, 5504, 75, 457], // Specify the data values array
                fill: false,
                borderColor: '#6366F1',
                backgroundColor: '#6366F1',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            xAxes: [{
                gridLines: {
                    display: false
                },
                ticks: {
                    display: false
                }
            }],
            yAxes: [{
                gridLines: {
                    display: false
                },
                ticks: {
                    display: false
                }
            }]
        },
        legend: {
            display: false
        }
    }
});

/* first chart js end */
/*second chart js start */

var ctx = document.getElementById("myChart2").getContext('2d');

var myChart2 = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Tokyo", "Mumbai", "Mexico City", "Shanghai", "Sao Paulo", "New York", "Karachi", "Buenos Aires", "Delhi", "Moscow"],
        datasets: [{
                label: 'Series 1',
                data: [500, 50, 2424, 14040, 14141, 4111, 4544, 47, 5555, 6811], // Specify the data values array
                fill: false,
                borderColor: '#D8D8D8',
                backgroundColor: '#D8D8D8',
                borderWidth: 1
            },
            {
                label: 'Series 2',
                data: [1288, 88942, 44545, 7588, 99, 242, 1417, 5504, 75, 457], // Specify the data values array
                fill: false,
                borderColor: '#6366F1',
                backgroundColor: '#6366F1',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            xAxes: [{
                gridLines: {
                    display: false
                },
                ticks: {
                    display: false
                }
            }],
            yAxes: [{
                gridLines: {
                    display: false
                },
                ticks: {
                    display: false
                }
            }]
        },
        legend: {
            display: false
        }
    }
});

/*second chart js start */

/* third chart js start*/
var ctx = document.getElementById("myChart3").getContext('2d');

var myChart3 = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Tokyo", "Mumbai", "Mexico City", "Shanghai", "Sao Paulo", "New York", "Karachi", "Buenos Aires", "Delhi", "Moscow"],
        datasets: [{
                label: 'Series 1',
                data: [500, 50, 2424, 14040, 14141, 4111, 4544, 47, 5555, 6811], // Specify the data values array
                fill: false,
                borderColor: '#D8D8D8',
                backgroundColor: '#D8D8D8',
                borderWidth: 1
            },
            {
                label: 'Series 2',
                data: [1288, 88942, 44545, 7588, 99, 242, 1417, 5504, 75, 457], // Specify the data values array
                fill: false,
                borderColor: '#6366F1',
                backgroundColor: '#6366F1',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            xAxes: [{
                gridLines: {
                    display: false
                },
                ticks: {
                    display: false
                }
            }],
            yAxes: [{
                gridLines: {
                    display: false
                },
                ticks: {
                    display: false
                }
            }]
        },
        legend: {
            display: false
        }
    }
});
/* third chart js end*/

/* line-chart js end */

/* Bar-chart js start */

var DEFAULT_DATASET_SIZE = 7,
    addedCount = 0,
    color = Chart.helpers.color;

var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

var chartColors = {
    red: 'rgb(255, 99, 132)',
    orange: 'rgb(255, 159, 64)',
    yellow: 'rgb(255, 205, 86)',
    green: 'rgb(75, 192, 192)',
    blue: 'rgb(54, 162, 235)',
    purple: 'rgb(153, 102, 255)',
    grey: 'rgb(231,233,237)'
};

function randomScalingFactor() {
    return Math.round(Math.random() * 100);
}

var barData = {
    labels: ["DEC 20", "JAN 21", "FEB 21", "MAR 21", "APR 21", "MAY 21"],
    datasets: [{
        label: '$1.7K',
        backgroundColor: '#38BDF8',
        borderColor: '#38BDF8',
        borderWidth: 1,
        data: [
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor()
        ]
    }, {
        label: '$2.4K',
        backgroundColor: '#6366F1',
        borderColor: '#6366F1',
        borderWidth: 1,
        data: [
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor()
        ]
    }]

};
var index = 11;
var ctx = document.getElementById("barChart").getContext("2d");
var barChart = new Chart(ctx, {
    type: 'bar',
    data: barData,
    options: {
        responsive: true,
        maintainAspectRation: true,
        legend: {
            position: 'top',
        },
        title: {
            display: true,
        },
        scales: {
            xAxes: [{
                gridLines: {
                    display: false
                },
            }],
        },
    }
});
/* Bar-chart js end */

/* Another line chart js start */
var ctx = document.getElementById("myChart4").getContext('2d');

var myChart4 = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["WED 20", "TODAY"],
        datasets: [{
                label: 'Current',
                data: [53, 5, 25, 27, 75, 45, 63, 20, 60, 42],
                fill: false,
                borderColor: '#D8D8D8',
                backgroundColor: '#D8D8D8',
                borderWidth: 1
            },
            {
                label: 'Previous',
                data: [10, 50, 20, 75, 30, 20, 5, 55, 75, 45],
                fill: false,
                borderColor: '#6366F1',
                backgroundColor: '#6366F1',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            xAxes: [{
                gridLines: {
                    display: false
                },
            }],
            yAxes: [{
                ticks: {
                    stepSize: 20,
                    min: 0,
                    max: 100
                }
            }],
        },
        legend: {
            position: 'right',
        },
    }
});
/* Another line chart js end*/


/* Doughnut chart js start */
$(document).ready(function() {
    var ctx = document.getElementById("myChart").getContext('2d');

    var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ["United States", "Italy", "Other"],
            datasets: [{
                data: [300, 200, 300],

                borderColor: ['#6366F1', '#38BDF8', '#3730A3'],
                backgroundColor: ['#6366F1', '#38BDF8', '#3730A3'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
                position: 'bottom',
            },
        }
    });
});
/* Doughnut chart js end */


/* other line chart js start */
var ctx = document.getElementById("myChart5").getContext('2d');

var myChart5 = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["WED 20", "TODAY"],
        datasets: [{
                label: 'Current',
                data: [53, 5, 25, 27, 75, 45, 63, 20, 60, 42],
                fill: false,
                borderColor: '#D8D8D8',
                backgroundColor: '#D8D8D8',
                borderWidth: 1
            },
            {
                label: 'Previous',
                data: [10, 50, 20, 75, 30, 20, 5, 55, 75, 45],
                fill: false,
                borderColor: '#6366F1',
                backgroundColor: '#6366F1',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            xAxes: [{
                gridLines: {
                    display: false
                },
            }],
            yAxes: [{
                ticks: {
                    stepSize: 20,
                    min: 0,
                    max: 100
                }
            }],
        },
        legend: {
            position: 'right',
        },
    }
});
/* other line chart js end*/

/* stacked chart js start */
var ctx = document.getElementById('stackedchart').getContext('2d');
var chart = new Chart(ctx, {
    type: "bar",
    data: {
        labels: ['DEC 20', 'JAN 21', 'FEB 21', 'MAR 21', 'APR 21', 'MAY 21'],
        datasets: [{
            label: 'Ventas',
            backgroundColor: '#C7D2FE',
            borderColor: '#C7D2FE',
            data: [100, 2, 102, 80, 34, 20],
        }, {
            label: 'Cancelados',
            backgroundColor: '#6366F1',
            borderColor: '#6366F1',
            data: [300, 203, 405, 56, 23, 50],
        }]
    },

    // Configuration options go here
    options: {
        title: {
            display: true,
        },
        tooltips: {
            mode: 'index',
            intersect: false,
        },
        responsive: true,
        scales: {
            xAxes: [{
                gridLines: {
                    display: false
                },
                ticks: {
                    display: false
                },
                stacked: true,
            }],
            yAxes: [{
                gridLines: {
                    display: false
                },
                ticks: {
                    display: false
                },
                stacked: true,
            }]
        },
        legend: {
            display: false
        }
    },
});

/* stacked chart js end */

/* Horizantal stacked chart js start */
var chart = new Chart(
    document.getElementsByClassName('chartjs-stacked-bar'), {
        type: 'horizontalBar',
        data: {
            labels: ["Languages"],
            datasets: [{
                    data: [35],
                    label: "a",
                    stack: "Languages",
                    backgroundColor: "#6366F1",
                }, {
                    data: [20],
                    label: "b",
                    stack: "Languages",
                    backgroundColor: "#3730A3",
                },
                {
                    data: [20],
                    label: "c",
                    stack: "Languages",
                    backgroundColor: "#38BDF8",
                },
                {
                    data: [40],
                    label: "d",
                    stack: "Languages",
                    backgroundColor: "#34D399",
                },
                {
                    data: [30],
                    label: "e",
                    stack: "Languages",
                    backgroundColor: "#E2E8F0",
                }
            ]
        },
        options: {
            scales: {
                xAxes: [{
                    gridLines: {
                        display: false
                    },
                    ticks: {
                        display: false
                    },
                    stacked: true,
                }],
                yAxes: [{
                    gridLines: {
                        display: false
                    },
                    ticks: {
                        display: false
                    },
                    stacked: true,
                }]
            },
            legend: {
                display: false
            },
            tooltips: {
                enabled: false
            }
        }
    });

/* Horizantal stacked chart js end */


/* date picker js start */
var separator = ' - ',
    dateFormat = 'MM/DD/YYYY';
var options = {
    autoUpdateInput: false,
    autoApply: true,
    locale: {
        format: dateFormat,
        separator: separator,
        applyLabel: '確認',
        cancelLabel: '取消'
    },
    minDate: moment().add(1, 'days'),
    maxDate: moment().add(359, 'days'),
    opens: "right"
};


$('[data-datepicker=separateRange]')
    .daterangepicker(options)
    .on('apply.daterangepicker', function(ev, picker) {
        var boolStart = this.name.match(/value_from_start_/g) == null ? false : true;
        var boolEnd = this.name.match(/value_from_end_/g) == null ? false : true;

        var mainName = this.name.replace('value_from_start_', '');
        if (boolEnd) {
            mainName = this.name.replace('value_from_end_', '');
            $(this).closest('form').find('[name=value_from_end_' + mainName + ']').blur();
        }

        $(this).closest('form').find('[name=value_from_start_' + mainName + ']').val(picker.startDate.format(dateFormat));
        $(this).closest('form').find('[name=value_from_end_' + mainName + ']').val(picker.endDate.format(dateFormat));

        $(this).trigger('change').trigger('keyup');
    })
    .on('show.daterangepicker', function(ev, picker) {
        var boolStart = this.name.match(/value_from_start_/g) == null ? false : true;
        var boolEnd = this.name.match(/value_from_end_/g) == null ? false : true;
        var mainName = this.name.replace('value_from_start_', '');
        if (boolEnd) {
            mainName = this.name.replace('value_from_end_', '');
        }

        var startDate = $(this).closest('form').find('[name=value_from_start_' + mainName + ']').val();
        var endDate = $(this).closest('form').find('[name=value_from_end_' + mainName + ']').val();

        $('[name=daterangepicker_start]').val(startDate).trigger('change').trigger('keyup');
        $('[name=daterangepicker_end]').val(endDate).trigger('change').trigger('keyup');

        if (boolEnd) {
            $('[name=daterangepicker_end]').focus();
        }
    });
/* date picker js end */